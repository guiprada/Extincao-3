-- Configuration
function love.conf(t)
	t.title = "come-come"
	--t.console = false
	t.console = true
    t.window.borderless = true
    t.window.resizable = false
	t.window.vsync = true
end
